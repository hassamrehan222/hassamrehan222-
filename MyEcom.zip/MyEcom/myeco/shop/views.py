from django.shortcuts import render
from .models import product, Contact
from math import ceil
from django.http import HttpResponse
MERCHANT_KEY = 'Your-Merchant-Key-Here'
# Create your views here.
def index(request):
    # products = product.objects.all()
    # print(product)
    # n = len(products)
    # nslides = n//4 + ceil((n/4)-(n//4))
    # params = {'no_of_slides' : nslides, 'range': range(nslides),'product': products}
    # return render(request, 'shop/index.html', params)

    allProds = []
    catprods = product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod = product.objects.filter(category=cat)
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])



    params = {'allProds':allProds}
    return render(request, 'shop/index.html', params)


def searchMatch(query, item):

    if query in item.product_name or query in item.category:
       return True
    else:
       return False

def search(request):
    query = request.GET.get('search')
    allProds = []
    catprods = product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prodtemp = product.objects.filter(category=cat)
        prod = [item for item in prodtemp if searchMatch(query, item)]

        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        if len(prod) != 0:
            allProds.append([prod, range(1, nSlides), nSlides])
    params = {'allProds': allProds, "msg": ""}
    if len(allProds) == 0 or len(query)<4:
        params = {'msg': "Please make sure to enter relevant search query"}
    return render(request, 'shop/search.html', params)



def about(request):
    return render(request, 'shop/about.html')

def contact(request):
    thank = False
    if request.method=="POST":

        name=request.POST.get('name', '')
        email=request.POST.get('email', '')
        phone=request.POST.get('phone', '')
        desc=request.POST.get('desc', '')
        print(name,email,phone, desc )
        contact = Contact(name=name, email=email, phone=phone, desc = desc)
        contact.save()
        thank = True

    return render(request, "shop/contact.html", {'thank' :thank})





def productview(request,myid):
    productss = product.objects.filter(id=myid)

    return render(request, 'shop/productview.html', {'product': productss[0]})

def checkout(request):
    return render(request, 'shop/checkout.html')